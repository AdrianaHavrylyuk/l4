Четверта лабораторна на Asp.Net Core MVC з EF Core
